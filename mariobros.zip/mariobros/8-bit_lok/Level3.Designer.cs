﻿namespace _8_bit_lok
{
    partial class Level3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.block1 = new System.Windows.Forms.Panel();
            this.screen = new System.Windows.Forms.Panel();
            this.player = new System.Windows.Forms.PictureBox();
            this.time1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.block2 = new System.Windows.Forms.PictureBox();
            this.block3 = new System.Windows.Forms.PictureBox();
            this.block4 = new System.Windows.Forms.PictureBox();
            this.block5 = new System.Windows.Forms.PictureBox();
            this.block6 = new System.Windows.Forms.PictureBox();
            this.block7 = new System.Windows.Forms.PictureBox();
            this.block8 = new System.Windows.Forms.PictureBox();
            this.block9 = new System.Windows.Forms.PictureBox();
            this.block10 = new System.Windows.Forms.PictureBox();
            this.endpoint = new System.Windows.Forms.PictureBox();
            this.lava = new System.Windows.Forms.PictureBox();
            this.screen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.block2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.block3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.block4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.block5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.block6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.block7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.block8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.block9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.block10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.endpoint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lava)).BeginInit();
            this.SuspendLayout();
            // 
            // block1
            // 
            this.block1.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.block1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.block1.Location = new System.Drawing.Point(0, 742);
            this.block1.Name = "block1";
            this.block1.Size = new System.Drawing.Size(1668, 19);
            this.block1.TabIndex = 0;
            // 
            // screen
            // 
            this.screen.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.screen.Controls.Add(this.lava);
            this.screen.Controls.Add(this.block10);
            this.screen.Controls.Add(this.block9);
            this.screen.Controls.Add(this.block8);
            this.screen.Controls.Add(this.block7);
            this.screen.Controls.Add(this.block6);
            this.screen.Controls.Add(this.block5);
            this.screen.Controls.Add(this.block4);
            this.screen.Controls.Add(this.block3);
            this.screen.Controls.Add(this.block2);
            this.screen.Controls.Add(this.pictureBox1);
            this.screen.Controls.Add(this.player);
            this.screen.Controls.Add(this.endpoint);
            this.screen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.screen.Location = new System.Drawing.Point(0, 0);
            this.screen.Name = "screen";
            this.screen.Size = new System.Drawing.Size(1668, 742);
            this.screen.TabIndex = 1;
            // 
            // player
            // 
            this.player.BackColor = System.Drawing.Color.Transparent;
            this.player.Image = global::_8_bit_lok.Properties.Resources.marioyoshi;
            this.player.Location = new System.Drawing.Point(132, 88);
            this.player.Name = "player";
            this.player.Size = new System.Drawing.Size(52, 59);
            this.player.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.player.TabIndex = 7;
            this.player.TabStop = false;
            // 
            // time1
            // 
            this.time1.Enabled = true;
            this.time1.Interval = 1;
            this.time1.Tick += new System.EventHandler(this.time1_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::_8_bit_lok.Properties.Resources.cblocksized;
            this.pictureBox1.Location = new System.Drawing.Point(9, 642);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(258, 63);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // block2
            // 
            this.block2.BackgroundImage = global::_8_bit_lok.Properties.Resources.cblocksized;
            this.block2.Location = new System.Drawing.Point(237, 466);
            this.block2.Name = "block2";
            this.block2.Size = new System.Drawing.Size(132, 63);
            this.block2.TabIndex = 9;
            this.block2.TabStop = false;
            // 
            // block3
            // 
            this.block3.BackgroundImage = global::_8_bit_lok.Properties.Resources.cblocksized;
            this.block3.Location = new System.Drawing.Point(416, 293);
            this.block3.Name = "block3";
            this.block3.Size = new System.Drawing.Size(132, 63);
            this.block3.TabIndex = 10;
            this.block3.TabStop = false;
            // 
            // block4
            // 
            this.block4.BackgroundImage = global::_8_bit_lok.Properties.Resources.cblocksized;
            this.block4.Location = new System.Drawing.Point(666, 642);
            this.block4.Name = "block4";
            this.block4.Size = new System.Drawing.Size(262, 63);
            this.block4.TabIndex = 11;
            this.block4.TabStop = false;
            // 
            // block5
            // 
            this.block5.BackgroundImage = global::_8_bit_lok.Properties.Resources.cblocksized;
            this.block5.Location = new System.Drawing.Point(971, 523);
            this.block5.Name = "block5";
            this.block5.Size = new System.Drawing.Size(65, 63);
            this.block5.TabIndex = 12;
            this.block5.TabStop = false;
            // 
            // block6
            // 
            this.block6.BackgroundImage = global::_8_bit_lok.Properties.Resources.cblocksized;
            this.block6.Location = new System.Drawing.Point(1042, 592);
            this.block6.Name = "block6";
            this.block6.Size = new System.Drawing.Size(132, 63);
            this.block6.TabIndex = 13;
            this.block6.TabStop = false;
            // 
            // block7
            // 
            this.block7.BackgroundImage = global::_8_bit_lok.Properties.Resources.cblocksized;
            this.block7.Location = new System.Drawing.Point(1214, 466);
            this.block7.Name = "block7";
            this.block7.Size = new System.Drawing.Size(64, 63);
            this.block7.TabIndex = 14;
            this.block7.TabStop = false;
            // 
            // block8
            // 
            this.block8.BackgroundImage = global::_8_bit_lok.Properties.Resources.cblocksized;
            this.block8.Location = new System.Drawing.Point(1290, 359);
            this.block8.Name = "block8";
            this.block8.Size = new System.Drawing.Size(64, 63);
            this.block8.TabIndex = 15;
            this.block8.TabStop = false;
            // 
            // block9
            // 
            this.block9.BackgroundImage = global::_8_bit_lok.Properties.Resources.cblocksized;
            this.block9.Location = new System.Drawing.Point(1375, 239);
            this.block9.Name = "block9";
            this.block9.Size = new System.Drawing.Size(70, 63);
            this.block9.TabIndex = 16;
            this.block9.TabStop = false;
            // 
            // block10
            // 
            this.block10.BackgroundImage = global::_8_bit_lok.Properties.Resources.cblocksized;
            this.block10.Location = new System.Drawing.Point(1473, 88);
            this.block10.Name = "block10";
            this.block10.Size = new System.Drawing.Size(192, 63);
            this.block10.TabIndex = 17;
            this.block10.TabStop = false;
            // 
            // endpoint
            // 
            this.endpoint.Location = new System.Drawing.Point(1565, 76);
            this.endpoint.Name = "endpoint";
            this.endpoint.Size = new System.Drawing.Size(100, 47);
            this.endpoint.TabIndex = 18;
            this.endpoint.TabStop = false;
            // 
            // lava
            // 
            this.lava.Location = new System.Drawing.Point(3, 733);
            this.lava.Name = "lava";
            this.lava.Size = new System.Drawing.Size(1662, 28);
            this.lava.TabIndex = 19;
            this.lava.TabStop = false;
            // 
            // Level3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1668, 761);
            this.Controls.Add(this.screen);
            this.Controls.Add(this.block1);
            this.Name = "Level3";
            this.Text = "Level3";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Level3_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Level3_KeyUp);
            this.screen.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.block2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.block3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.block4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.block5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.block6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.block7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.block8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.block9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.block10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.endpoint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lava)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel block1;
        private System.Windows.Forms.Panel screen;
        private System.Windows.Forms.PictureBox player;
        private System.Windows.Forms.Timer time1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox block10;
        private System.Windows.Forms.PictureBox block9;
        private System.Windows.Forms.PictureBox block8;
        private System.Windows.Forms.PictureBox block7;
        private System.Windows.Forms.PictureBox block6;
        private System.Windows.Forms.PictureBox block5;
        private System.Windows.Forms.PictureBox block4;
        private System.Windows.Forms.PictureBox block3;
        private System.Windows.Forms.PictureBox block2;
        private System.Windows.Forms.PictureBox endpoint;
        private System.Windows.Forms.PictureBox lava;
    }
}